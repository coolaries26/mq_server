QTune - a queue tuning tool for WebSphere MQ
--------------------------------------------

On the Distributed platforms, when the queue manager loads a local
queue, it allocates internal memory buffers to hold information
about the queue and messages on it. 

While the default values of these buffers are chosen to be good for most 
applications, there may be times when custom tuning can improve performance. 

Unfortunately, there is currently no easy external mechanism for making 
these changes. SupportPac MP01 describes a process for setting one 
of these tuning values. See also the TechNotes at 
http://www-01.ibm.com/support/docview.wss?uid=swg21246541
and http://www-01.ibm.com/support/docview.wss?uid=swg21162114

This tool can achieve the same effect with a simpler and more direct 
manipulation of a queue's attributes. It allows setting of 
three independent values: the size of the persistent message buffer,
the size of the non-persistent message buffer, and the 
maximum size of the queue.

It does not change the default settings for newly-created queues.
That can only be done by editing the ini file as described
in the referenced technotes. But most of the time you are 
unlikely to want to change default values, only the settings
for a few individual queues.

QTune changes the settings on existing queues, and therefore can be 
used against the SYSTEM.CLUSTER.TRANSMIT.QUEUE, which cannot 
normally be deleted and recreated. 

Why would I use it?
-------------------
"Queue files" are the files in the operating system which hold data
about each queue. These sit in the queue manager's data directory,
with one file per queue. For example, look at the files under 
/var/mqm/qmgrs/<QMGR>/queues. Each queue file contains control 
information, and messages that need to be stored for that queue. Not all
messages are written to these queue files; for example non-persistent
messages may never be written to disk at all.  

The queue manager uses internal memory buffers to hold newly-put 
messages, both persistent and non-persistent. If a message fits into 
the buffer, it does not need to be written to the queue file. Otherwise, 
the message is spilled to disk. Changing the buffer sizes can limit 
the amount of data that is written to the disks. These buffers are shared 
by all applications which open the same queue, whether they do it directly
or indirectly such as via an alias or remote definition.

For example, sending large non-persistent messages through a 
queue that has been tuned with a larger buffer will reduce the amount 
of disk I/O performed.  

While there is also a buffer for persistent messages, this only
affects the I/O to the queue files. It does not change how much
data gets written to the recovery logs, so there is likely still
to be I/O to that filesystem. 

Changing the maximum queue file size is simply a way of restricting
the space used on disk; this might be important to stop one queue
filling an entire filesystem.

How do I use it?
----------------

Running the tool with the -h flag shows the details of
the parameters and valid settings for each. If no attributes
are specified, then the current settings for each attribute
are displayed but no changes are made. 

This is only valid for LOCAL queue definitions; other queues such
as remote and alias definitions will always resolve to a local
queue, and do not need these tuning parameters themselves.

The exact names of the parameters, and the values that you can
enter, are different from those given in MP01 to simplify
the user input. In particular, note the units in which each
value is given.

Some parameters can be set to -1, which means use whatever
the current queue manager default value is, instead of
having an explicit value. That default may change between
releases of MQ unless you override it in the ini file.

Process
-------
1. From a running queue manager, define any required local queues

2. Use the dspmqfls command to find the real directory
   corresponding to queues. For example,
      /var/mqm/qmgrs/QMA/queues/SYSTEM!DEFAULT!LOCAL!QUEUE   
   You do not need to use dspmqfls if you only want to 
   look at current values - instead you can use the -m and -q
   options to the command. 
   
   If you have multiple versions of MQ installed, the dspmqfls 
   command must be the one that is associated with this queue 
   manager's installation. Run setmqenv before dspmqfls or QTune, 
   unless you use the -d parameter to explicitly name the directory.
        
3. If you want to make updates, stop the queue manager to ensure 
   noone is accessing the file. This step is not necessary if
   you only want to look at current values. The queue does not
   need to be empty.
   
4. Use the directory as input to the QTune command, along with
   any changes to the attributes. For example,
      java -jar qtune.jar -d <directory> -a npBuff=256
   The command output will show the previous settings for the
   queue before setting the new value.
   
5. Restart the queue manager.

6. If you are using linear logging, do a rcdmqimg for the 
   modified queue to ensure media recovery will incorporate
   your changes.

The program returns zero if successful, non-zero otherwise.

Example Output
--------------

c:\> java -jar qtune.jar -d c:\mqm\qmgrs\QMA\queues\SYSTEM!DEFAULT!LOCAL!QUEUE

File c:\mqm\qmgrs\QMA\queues\SYSTEM!DEFAULT!LOCAL!QUEUE\q
Stored npBuff     = 64 kB
Stored pBuff      = QMgr default
Stored maxQSize   = 2,097,151 MB

C:\>java -jar qtune.jar -d c:\mqm\qmgrs\QMA\queues\SYSTEM!CLUSTER!TRANSMIT!QUEUE -a npBuff=256
File c:\mqm\qmgrs\QMA\queues\SYSTEM!CLUSTER!TRANSMIT!QUEUE\q
Stored npBuff     = 128 kB
Stored pBuff      = QMgr default
Stored maxQSize   = 2,097,151 MB
Setting attribute npBuff

Note the difference in attribute parsing if you use the included .bat script - the
quotes around the attribute seem to be necessary.
C:\>qtune.bat -d c:\mqm\qmgrs\QMA\queues\SYSTEM!CLUSTER!TRANSMIT!QUEUE -a "npBuff=256"
File c:\mqm\qmgrs\QMA\queues\SYSTEM!CLUSTER!TRANSMIT!QUEUE\q
Stored npBuff     = 128 kB
Stored pBuff      = QMgr default
Stored maxQSize   = 2,097,151 MB
Setting attribute npBuff

C:\>java -jar qtune.jar -d c:\mqm\qmgrs\QMA\queues\SYSTEM!CLUSTER!TRANSMIT!QUEUE
File c:\mqm\qmgrs\QMA\queues\SYSTEM!CLUSTER!TRANSMIT!QUEUE\q
Stored npBuff     = 256 kB
Stored pBuff      = QMgr default
Stored maxQSize   = 2,097,151 MB
      
WARNINGS
--------      
Note that this tool is completely unofficial and unsupported!

It has been designed for MQ V6, and V7.x. No other versions 
of MQ are likely to work.

While it tries to ensure no other process is modifying the queue 
file at the same time, this cannot be guaranteed. If you run the 
tool while the queue manager is running, any changes are likely to 
be overwritten and in theory could even cause corruption of the 
queue data.

Do not overuse this ... be selective. If you set every queue
to the maximum values, each loaded queue would use 200MB of
shared memory. Only tune queues where it is necessary. 

Make sure you have enough memory in your system to handle the 
workload; paging memory may cause more of an overhead than 
the filesystem I/O that would otherwise happen with the default
settings. Monitoring for performance - memory usage, I/O, CPU -  
is critical to validate your changes. 

-----------------------------------------------------
# SCCSID: @(#) com.ibm.mq.explorer.ms0p.qtune/src/README.txt, supportpacs, MS0P  1.7 12/07/08 09:07:22
