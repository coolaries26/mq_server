PubQStat
--------

This program is intended to run as a service alongside its owning 
queue manager, making regular queries on queue statistics, and publish 
them to a topic.

The list of queues to be monitored can either be provided explicitly 
on the command line, or in a named file. Wildcards can be used in the 
list.

Configuration
-------------
On the Distributed platforms, you can set up Services which are 
automatically started as the queue manager starts.

A suggested configuration is 
  DEFINE SERVICE(PubQStat)
   CONTROL(QMGR)
   SERVTYPE(SERVER)
   STARTCMD(<path>\pubqstat.cmd)
   STARTARG(-m +QMNAME+ -f <path>\pubqstat.list)              
   STOPCMD(+MQ_INSTALL_PATH+bin/amqsstop)
   STOPARG(-m +QMNAME+ -p +MQ_SERVER_PID+)                              
   STDOUT(<path>\pubqstat.out)
   STDERR(<path>\pubqstat.err)

The command path and output paths are probably going to be different. 

It is important that the queue manager name be given as the first 
parameter (second token) in the STARTARG attribute. This is to help 
establish the correct environment when you have more than one MQ installation
on your system. There is no requirement to have a STOPCMD definition; the 
service will automatically stop when the queue manager ends. The definition
here may allow you to manually stop the program.

You may need to edit the startup batch program or shell script to modify paths, 
depending on where you have installed the MQ code. 
   
The STARTARG attribute sets these parameters to the command. Only the queue
manager name is mandatory.  
           
Usage: pubqstat [-h] -m qmgr [-q queues | -f file ] [-i interval] [-t topic]
Options:
 -h : Show this help message
 -m : Queue Manager 
 -f : File containing list of queues
 -q : List of Queues (use '*' and ',' for multiple) [Default '*']
 -t : Topic for publication of statistics           [Default SYSTEM.ADMIN.QSTATS]
 -i : Interval for repeating queries (in seconds)   [Default 600]
 

Output Format
-------------
The collected data is published on a nominated topic to which any application
can subscribe. The publication consists of a single message containing data for
all the configuration queues. It is an XML-style message which looks like
    <MQStatistics Time="MMM dd yyyy HH:mm:ss",QueueManager="%s">
      <Queue Name="QName1",MsgEnq="99",MsgDeq="99",HiDepth="99",TimeSinceReset="99"/>
      <Queue Name="QName2",MsgEnq="99",MsgDeq="99",HiDepth="99",TimeSinceReset="99"/>
      ...
    </MQStatistics>
where the fields are filled in with the collected values. This should make it 
easy to parse.
 

Notes
-----
1. Because this command is intended to run as a service, it only
   uses local bindings; there is no support for client connections to
   remote queue managers
2. The command uses RESET QSTATS to collect the data. You should only
   have one monitoring program active that uses that command; otherwise
   the programs will compete and get incorrect data. If you are using
   the Activity Viewer that is also included in the MS0P SupportPac,
   that is one such monitor using RESET QSTATS and it should be disabled.
3. The program ought to be capable of running on z/OS with a suitable
   startup job, but that is not provided in this package.
4. Program is compiled and built against MQ V7.1 and Java6; that will be 
   the mininum runtime level.
         
-----------------------------------------------------
# SCCSID: @(#) com.ibm.mq.explorer.ms0p.pubqstat/src/README.txt, supportpacs, MS0P  1.2 12/07/02 12:40:03