MQIDecode - a developer's aid for WebSphere MQ
----------------------------------------------

This is a simple tool to decode values in the
MQI. It turns a number into the corresponding symbolic
values.

You enter the number (either in decimal or hex) and
the prefix that defines which type of MQI value it is. The
prefix is the part of the symbolic name before the first
underscore. For example, use MQIACF or MQOO. If you use
the -n flag, then the underscore is not assumed. This would
allow matching, for example, to look in both MQIA and MQIACH
ranges. 

By default, the number is treated as a bit mask (such as 
in the Options field of most MQI structures); by specifying
the -e flag, the number is treated as an absolute value to 
search for. When decoding the number as flags, unrecognised
values are shown.

Usage
----- 
mqidecode [-p prefix] [-v value] [-m | -e] [-n]

Options:
  -p : Prefix such as MQOO or MQAT
  -v : Value in either decimal (eg 1234) or hexadecimal (eg 0x1234)
  -m : The value is treated as a bit mask; decode each bit (default)
  -e : The value is in an enumerated range
  -n : Do not assume an underscore immediately after the prefix
The program returns 0 for success, non-zero for failure.

For example, to decode the Open Options flags:
    $ ./mqidecode -p MQOO -v 0x10042456 
    MQOO_INPUT_SHARED (0x00000002)
    MQOO_INPUT_EXCLUSIVE (0x00000004)
    MQOO_OUTPUT (0x00000010)
    MQOO_SET (0x00000040)
    MQOO_SET_IDENTITY_CONTEXT (0x00000400)
    MQOO_FAIL_IF_QUIESCING (0x00002000)
    MQOO_RESOLVE_LOCAL_Q (0x00040000)
    No definitions found for flags of value 0x10000000
    
To decode the MQ ApplicationType value:    
    $ ./mqidecode -p MQAT -v 6 -e
    MQAT_AIX/MQAT_UNIX
    
Notes
-----    
Sometimes a number may match more than one value. In such
cases, the possible values are all shown on a single line
separated with the '/' character.

Access to the MQ Java client jars are required for this program
to work because this program uses the MQConstants.lookup() method 
from these classes.  Scripts are provided for Unix and Windows 
platforms that attempt to set the correct classpath entries. You 
might need to edit these scripts to match your installation. 

This program was compiled against an MQ V7.1 Java installation to match
the prereq for the rest of this version of MS0P. Make sure the
classpath that is set in the launching batch or script file is pointing
at a V7.1 installation even if you still have a V7.0.1 also available
on the machine.

# SCCSID: @(#) com.ibm.mq.explorer.ms0p.mqidecode/src/README.txt, supportpacs, MS0P  1.4 11/10/24 19:42:59