static char *sccsid = "@(#) com.ibm.mq.explorer.events.stats/cmdevent/cmdevent.c, supportpacs, MS0P          1.8  07/01/08 18:57:43";
/*********************************************************************/
/* MODULE: cmdevent.c                                                */
/*                                                                   */
/* (C) Copyright IBM 2003, 2006                                      */
/*                                                                   */
/* AUTHOR: Mark Taylor, IBM Hursley                                  */
/*                                                                   */
/* DESCRIPTION: API Exit emulating Command Events for PCF operations */
/*                                                                   */
/*   In WebSphere MQ for z/OS V6, a new type of event message was    */
/*   introduced: the Command Event. This API Exit code emulates a    */
/*   subset of that function - it can monitor all commands issued    */
/*   through PCF messages to the command server, but it cannot trap  */
/*   runmqsc console commands.                                       */
/*                                                                   */
/*   Work done by tools such as the MQ Explorer or by                */
/*   SupportPac MO71 can be monitored through this exit.             */
/*                                                                   */
/*   Any up-to-date management tool that processes event messages    */
/*   should be able to read these events and format them.            */
/*                                                                   */
/*   Read the "Monitoring MQ" book for more details of these Event   */
/*   Messages.                                                       */
/*                                                                   */
/*   The Data attribute in qm.ini or mqs.ini should be set to        */
/*   ENABLED, DISABLED or NODISPLAY. Any changes to this value       */
/*   require a restart of the queue manager. You can also set        */
/*   it to DEBUG, which is the same as ENABLED except it also        */
/*   creates a log file. (Not much is written in that for now.)      */
/*                                                                   */
/* HISTORY: The original version of this exit was developed for      */
/*          an article I wrote and which was published               */
/*          by Xephon in MQ Update, November 2003. It decoded the    */
/*          commands, and wrote them as text to a log file.          */
/*                                                                   */
/*          This almost totally rewritten version was released in    */
/*          September 2006, as part of SupportPac MS0P.              */
/*********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <cmqc.h>
#include <cmqxc.h>
#include <cmqcfc.h>

#ifndef TRUE
#define TRUE (1)
#endif

#ifndef FALSE
#define FALSE (0)
#endif

/*********************************************************************/
/* Standard MQ Entrypoint. Not directly used, but                    */
/* required by some platforms.                                       */
/*********************************************************************/
void *MQStart(){return 0;}

/*********************************************************************/
/* Declare internal functions. All except the                        */
/* entrypoint can be static as they're not used by any other module. */
/*********************************************************************/
MQ_INIT_EXIT EntryPoint;
static MQ_PUT_EXIT  PutResponse;
static MQ_GET_EXIT  GetCommand;

static int isInquire(MQLONG cmd);
static void writeCommandEvent(MQHCONN hConn, PMQMD pMQMD);

/*********************************************************************/
/* Variables and definitions                                         */
/*********************************************************************/
#define CMDEV_DISABLED  (0)
#define CMDEV_ENABLED   (1)
#define CMDEV_NODISPLAY (2)

int cmdev = CMDEV_DISABLED;
MQCHAR32 exitData;

char *eventQueue = "SYSTEM.ADMIN.COMMAND.EVENT";

MQHCONN hConn = MQHC_UNUSABLE_HCONN;
MQHOBJ  hObj  = MQHO_UNUSABLE_HOBJ;

MQOD   od = {MQOD_DEFAULT};
MQMD   md = {MQMD_DEFAULT};
MQPMO  pmo = {MQPMO_DEFAULT};


MQCFH  cfh  = {MQCFH_DEFAULT};
MQCFIN cfin = {MQCFIN_DEFAULT};
MQCFGR cfgr = {MQCFGR_DEFAULT};
MQCFST cfst = {MQCFST_DEFAULT};
MQCFBS cfbs = {MQCFBS_DEFAULT};

MQLONG messageLength;
char   buffer[8192];         /* Should be big enough for any command */

int commandSucceeded = TRUE;

/*********************************************************************/
/* In case we want to do some debug of this exit and/or log errors   */
/*********************************************************************/
int debug = FALSE;

#if MQAT_DEFAULT == MQAT_WINDOWS_NT
#define LOGFILE "c:\\mqm\\exits\\cmdevent.txt"
#else
#define LOGFILE "/var/mqm/exits/cmdevent.txt"
#endif

FILE *fp = NULL;

/*********************************************************************/
/* Initialisation function.                                          */
/* This is called as an application connects to the queue manager.   */
/*********************************************************************/
void MQENTRY EntryPoint ( PMQAXP   pExitParms
	                , PMQAXC   pExitContext
	                , PMQLONG  pCompCode
	                , PMQLONG  pReason
	                )
{
  MQLONG rc    = 0;
  char buf[256]={0};
  int i;

#ifdef _REENTRANT
  char *t="threaded";
#else
  char *t="unthreaded";
#endif

  /*******************************************************************/
  /* Only take it any further if we're inside the command server.    */
  /* We can tell that very simply, from an environment setting that  */
  /* is passed to the API Exit.                                      */
  /*******************************************************************/
  if (pExitContext->Environment != MQXE_COMMAND_SERVER)
    return;

  /*******************************************************************/
  /* Also, only continue if it's not marked as "disabled"            */
  /*******************************************************************/
  strncpy(exitData,pExitParms->ExitData,sizeof(exitData));
  for (i=0;i<sizeof(exitData);i++) exitData[i] = toupper(exitData[i]);

  if (!strncmp(exitData,"DISABLED",sizeof(exitData)))
    cmdev = CMDEV_DISABLED;
  else if (!strncmp(exitData,"ENABLED",sizeof(exitData)))
    cmdev = CMDEV_ENABLED;
  else if (!strncmp(exitData,"NODISPLAY",sizeof(exitData)))
    cmdev = CMDEV_NODISPLAY;
  else if (!strncmp(exitData,"DEBUG",sizeof(exitData)))
  {
    cmdev = CMDEV_ENABLED;
    debug = TRUE;
  }  
  
  if (cmdev == CMDEV_DISABLED)
    return;

  /*******************************************************************/
  /* This string is logged in MQ's trace so we see it's been called. */
  /*******************************************************************/
  sprintf(buf,"CMDEVENT ver %s %s (%s)\n",__DATE__,__TIME__,t);
  memcpy(pExitParms->ExitPDArea,buf,48);
  
  if (debug)
  {
    fp = fopen(LOGFILE,"a+");
    if (fp)
      setbuf(fp,0);
  }
  
  if (fp) fprintf(fp,"CmdEvent API Exit started. Build: %s %s \n",__DATE__,__TIME__);
  
  /*******************************************************************/
  /* Register for verbs we're interested in - only MQPUT and MQGET.  */
  /* There are no resources we need to release at MQDISC/exit, so no */
  /* need to register for the termination point. (The event queue    */
  /* will be closed for us by the MQDISC, and any debug log file     */
  /* will be closed by the process exit.)                            */
  /*******************************************************************/
  if (rc == 0)
  {
    MQXEP ( pExitParms->Hconfig, MQXR_AFTER, MQXF_PUT
	  , (PMQFUNC) PutResponse, 0, pCompCode, pReason);
    rc += *pCompCode;
    MQXEP ( pExitParms->Hconfig , MQXR_AFTER, MQXF_GET
	  , (PMQFUNC) GetCommand, 0, pCompCode, pReason);
    rc += *pCompCode;
  }

  /*******************************************************************/
  /* If there was any error in the setup, force an exit. The command */
  /* server must not be allowed to continue if operations cannot be  */
  /* logged. An MQ trace will show an error from the API Exit that   */
  /* can then be tracked.                                            */
  /* Of course, you can change this policy if you like.              */
  /*******************************************************************/
  if (rc > 0) {
    pExitParms->ExitResponse = MQXCC_FAILED;
    if (fp)
    {
      fflush(fp);
      fclose(fp);
      fp = NULL;
    }
  }  

  return;
}


/*********************************************************************/
/* Collect information about commands read from the input queue.     */
/* The event message is built here, assuming the command succeeds.   */
/* But it is not written to the event queue yet.                     */
/*                                                                   */
/* The command server on Distributed platforms is synchronous, and   */
/* never starts to process a new command before the old one has been */
/* completely dealt with, so there should never be any confusion     */
/* about which command the response is referring to.                 */
/*                                                                   */
/* There is not a lot of error checking in here, so a malformed      */
/* command might break the exit.                                     */
/*********************************************************************/
static void MQENTRY GetCommand ( PMQAXP    pExitParms
	                 , PMQAXC    pExitContext
	                 , PMQHCONN  pHconn
	                 , PMQHOBJ   pHobj
	                 , PPMQMD    ppMsgDesc
	                 , PPMQGMO   ppGetMsgOpts
	                 , PMQLONG   pBufferLength
	                 , PPMQVOID  ppBuffer
	                 , PPMQLONG  ppDataLength
	                 , PMQLONG   pCompCode
	                 , PMQLONG   pReason
	                 )
{
  PMQMD pMQMD     = *ppMsgDesc;
  PMQCFH pCommand = *ppBuffer;

  char *pCommandData = ((char *)pCommand) + sizeof(MQCFH);
  int dataLength = (**ppDataLength) - sizeof(MQCFH);


  int fieldLength;

  if (*pCompCode != MQCC_OK || cmdev == CMDEV_DISABLED)
    return;

  /*******************************************************************/
  /* Check that the format of the message is not completely bogus.   */
  /*******************************************************************/
  if ((strncmp(pMQMD->Format,MQFMT_ADMIN,8) ==0) ||
      (pMQMD->MsgType == MQMT_REQUEST))
  {
    commandSucceeded = TRUE;               /* Reset the success flag */

    if ((cmdev == CMDEV_NODISPLAY) && (isInquire(pCommand->Command) == TRUE))
    {
      messageLength = 0; /* Ensure PutResponse doesn't log the cmd   */
    }
    else
    {
      /***************************************************************/
      /* Build the event message, but don't try to put it yet        */
      /***************************************************************/
      messageLength = 0;

      /***************************************************************/
      /* Set the MQMD fields                                         */
      /* We're setting some of the context fields, so must ensure    */
      /* that the queue was opened (and pmo set) to permit this. As  */
      /* this exit is running inside the command server, it will     */
      /* have complete authority to do this.                         */
      /***************************************************************/
      md.Report      = MQRO_NONE;
      md.MsgType     = MQMT_DATAGRAM;
      md.Expiry      = MQEI_UNLIMITED;
      md.Persistence = MQPER_PERSISTENCE_AS_Q_DEF;
      md.PutApplType = MQAT_QMGR;
      strncpy(md.Format,MQFMT_EVENT,MQ_FORMAT_LENGTH);
        
      memset(md.PutApplName,0,MQ_APPL_NAME_LENGTH);     
      memset(md.ReplyToQMgr,0,MQ_Q_MGR_NAME_LENGTH);
      strncpy(md.PutApplName,pExitParms->QMgrName,MQ_APPL_NAME_LENGTH);
      strncpy(md.ReplyToQMgr,pExitParms->QMgrName,MQ_Q_MGR_NAME_LENGTH);
    

      /***************************************************************/
      /* The MQCFH header describes the rest of the event message    */
      /***************************************************************/
      cfh.Type = MQCFT_EVENT;
      cfh.Version = MQCFH_VERSION_3;
      cfh.Command = MQCMD_COMMAND_EVENT;
      cfh.MsgSeqNumber = 1;
      cfh.Control = MQCFC_LAST;
      cfh.CompCode = MQCC_OK;
      cfh.Reason = MQRC_COMMAND_PCF;
      cfh.ParameterCount = 2;                /* There are two GROUPS */
      memcpy(&buffer[messageLength],&cfh,sizeof(cfh));
      messageLength += sizeof(cfh);

      /***************************************************************/
      /* First Group of parameters, describing the context           */
      /***************************************************************/
      cfgr.Parameter = MQGACF_COMMAND_CONTEXT;
      cfgr.ParameterCount = 9;
      memcpy(&buffer[messageLength],&cfgr,sizeof(cfgr));
      messageLength += sizeof(cfgr);

/*1*/ fieldLength = MQ_USER_ID_LENGTH;
      cfst.StrucLength  = MQCFST_STRUC_LENGTH_FIXED + fieldLength;
      cfst.Parameter    = MQCACF_EVENT_USER_ID;
      cfst.StringLength = fieldLength;
      memcpy(&buffer[messageLength],&cfst,MQCFST_STRUC_LENGTH_FIXED);
      messageLength += MQCFST_STRUC_LENGTH_FIXED;
      memcpy(&buffer[messageLength],pMQMD->UserIdentifier,fieldLength);
      messageLength += fieldLength;

/*2*/ cfin.Parameter = MQIACF_EVENT_ORIGIN;
      cfin.Value = MQEVO_MSG;
      memcpy(&buffer[messageLength],&cfin,sizeof(cfin));
      messageLength += sizeof(cfin);

/*3*/ fieldLength = MQ_Q_MGR_NAME_LENGTH;
      cfst.StrucLength  = MQCFST_STRUC_LENGTH_FIXED + fieldLength;
      cfst.Parameter    = MQCACF_EVENT_Q_MGR;
      cfst.StringLength = fieldLength;
      memcpy(&buffer[messageLength],&cfst,MQCFST_STRUC_LENGTH_FIXED);
      messageLength += MQCFST_STRUC_LENGTH_FIXED;
      memcpy(&buffer[messageLength],pExitParms->QMgrName,fieldLength);
      messageLength += fieldLength;

/*4*/ fieldLength = MQ_ACCOUNTING_TOKEN_LENGTH;
      cfbs.StrucLength  = MQCFBS_STRUC_LENGTH_FIXED + fieldLength;
      cfbs.Parameter    = MQBACF_EVENT_ACCOUNTING_TOKEN;
      cfbs.StringLength = fieldLength;
      memcpy(&buffer[messageLength],&cfbs,MQCFST_STRUC_LENGTH_FIXED);
      messageLength += MQCFBS_STRUC_LENGTH_FIXED;
      memcpy(&buffer[messageLength],pMQMD->AccountingToken,fieldLength);
      messageLength += fieldLength;

/*5*/ fieldLength = MQ_APPL_IDENTITY_DATA_LENGTH;
      cfst.StrucLength  = MQCFST_STRUC_LENGTH_FIXED + fieldLength;
      cfst.Parameter    = MQCACF_EVENT_APPL_IDENTITY;
      cfst.StringLength = fieldLength;
      memcpy(&buffer[messageLength],&cfst,MQCFST_STRUC_LENGTH_FIXED);
      messageLength += MQCFST_STRUC_LENGTH_FIXED;
      memcpy(&buffer[messageLength],pMQMD->ApplIdentityData,fieldLength);
      messageLength += fieldLength;

/*6*/ cfin.Parameter = MQIACF_EVENT_APPL_TYPE;
      cfin.Value = pMQMD->PutApplType;
      memcpy(&buffer[messageLength],&cfin,sizeof(cfin));
      messageLength += sizeof(cfin);

/*7*/ fieldLength       = MQ_APPL_NAME_LENGTH;
      cfst.StrucLength  = MQCFST_STRUC_LENGTH_FIXED + fieldLength;
      cfst.Parameter    = MQCACF_EVENT_APPL_NAME;
      cfst.StringLength = fieldLength;
      memcpy(&buffer[messageLength],&cfst,MQCFST_STRUC_LENGTH_FIXED);
      messageLength += MQCFST_STRUC_LENGTH_FIXED;
      memcpy(&buffer[messageLength],pMQMD->PutApplName,fieldLength);
      messageLength += fieldLength;

/*8*/ fieldLength = MQ_APPL_ORIGIN_DATA_LENGTH;
      cfst.StrucLength  = MQCFST_STRUC_LENGTH_FIXED + fieldLength;
      cfst.Parameter    = MQCACF_EVENT_APPL_ORIGIN;
      cfst.StringLength = fieldLength;
      memcpy(&buffer[messageLength],&cfst,MQCFST_STRUC_LENGTH_FIXED);
      messageLength += MQCFST_STRUC_LENGTH_FIXED;
      memcpy(&buffer[messageLength],pMQMD->ApplOriginData,fieldLength);
      messageLength += fieldLength;

/*9*/ cfin.Parameter = MQIACF_COMMAND;
      cfin.Value = pCommand->Command;
      memcpy(&buffer[messageLength],&cfin,sizeof(cfin));
      messageLength += sizeof(cfin);

      /***************************************************************/
      /* Second Group of parameters, containing the actual command.  */
      /* For a PCF command, all we need to do is copy the body of    */
      /* the original message after the group header.                */
      /***************************************************************/
      cfgr.Parameter = MQGACF_COMMAND_DATA;
      cfgr.ParameterCount = pCommand->ParameterCount;
      memcpy(&buffer[messageLength],&cfgr,sizeof(cfgr));
      messageLength += sizeof(cfgr);

      if ((messageLength + dataLength) > sizeof(buffer))
      {
	/*************************************************************/
	/* Another basic check to ensure we don't overrun the        */
	/* message buffer. There should be no genuine command that   */
	/* is this long. We just will not log this enormous request. */
	/*************************************************************/
	if (fp) fprintf(fp,"Enormous command received - will not be logged\n");
	messageLength = 0;
      }
      else
      {
	memcpy(&buffer[messageLength],pCommandData,dataLength);
	messageLength += dataLength;
      }
    }
  }
  return;
}

/*********************************************************************/
/* Function: PutResponse                                             */
/*   Called when the command server is sending back the responses    */
/*   to the management application. We will learn here whether the   */
/*   command was successful, and if so, we put the event message to  */
/*   its queue.                                                      */
/*   We are called AFTER the actual reply has been sent. This is so  */
/*   I can copy the date/time from the MQMD - can't leave it blank   */
/*   when we are setting all context fields.                         */
/*                                                                   */
/*   Note that while the command server might fail to put its replies*/
/*   to the ReplyQ (eg if it is full), the hObj should always refer  */
/*   to a valid queue. The command server opens the reply queue      */
/*   before doing any work - so we KNOW that the reply queue does    */
/*   (or did) exist and therefore we WILL see MQPUT attempts from the*/
/*   command server as it responds to commands.                      */
/*********************************************************************/
static void MQENTRY PutResponse ( PMQAXP    pExitParms
	                 , PMQAXC    pExitContext
	                 , PMQHCONN  pHconn
	                 , PMQHOBJ   pHobj
	                 , PPMQMD    ppMsgDesc
	                 , PPMQPMO   ppPutMsgOpts
	                 , PMQLONG   pBufferLength
	                 , PPMQVOID  ppBuffer
	                 , PMQLONG   pCompCode
	                 , PMQLONG   pReason
	                 )
{
  PMQMD  pMQMD     = *ppMsgDesc;
  PMQCFH pResponse = *ppBuffer;

  if (cmdev == CMDEV_DISABLED)
    return;

#if 0 
  /* We should log the command EVEN IF putting the reply had failed.
   * For example, if the application's replyQ is full.
   * So I'm going to block out this test.     
   */  
  if (*pCompCode != MQCC_OK)
    return;
#endif    
    
  /*******************************************************************/
  /* Do a basic sanity check on the message being sent back.         */
  /*******************************************************************/
  if ((strncmp(pMQMD->Format,MQFMT_ADMIN,8) ==0) &&
      (pMQMD->MsgType == MQMT_REPLY))
  {
    /*****************************************************************/
    /* If any of the portions failed, then don't write an event.     */
    /*****************************************************************/
    if (pResponse->CompCode == MQCC_FAILED)
      commandSucceeded = FALSE;

    /*****************************************************************/
    /* Some commands, notably the Inquire set, may get multiple      */
    /* responses. Only write the event as the last in a set is sent. */
    /*****************************************************************/
    if (pResponse->Control == MQCFC_LAST && commandSucceeded == TRUE)
    {
      writeCommandEvent(*pHconn,pMQMD);  
    }
  }

  return;
}

/*********************************************************************/
/* This function writes the event message to the queue.              */
/*********************************************************************/
static void writeCommandEvent(MQHCONN hConn, PMQMD pMQMD) 
{
  MQLONG o_options;
  MQLONG cc;
  MQLONG rc;
   
  static int prev_rc = MQRC_NONE;
  
  if (hObj == MQHO_UNUSABLE_HOBJ)
  {
    o_options = MQOO_OUTPUT |
	            MQOO_FAIL_IF_QUIESCING |
	            MQOO_SET_ALL_CONTEXT; /* We will have authority! */
    strncpy(od.ObjectName, eventQueue, (size_t)MQ_Q_NAME_LENGTH);
    MQOPEN(hConn,&od,o_options,&hObj,&cc,&rc);
    if (cc != MQCC_OK)
    {
      cmdev = CMDEV_DISABLED;
      if (fp) fprintf(fp,"MQOPEN failed. CC: %d RC: %d\n",cc,rc);  
    }
  }
  
  if (hObj != MQHO_UNUSABLE_HOBJ && messageLength > 0)
  {
    pmo.Options = MQPMO_NO_SYNCPOINT;
    pmo.Options |= MQPMO_NEW_MSG_ID;
    pmo.Options |= MQPMO_NEW_CORREL_ID;
    pmo.Options |= MQPMO_SET_ALL_CONTEXT;
	
    if (pMQMD != NULL) 
    {
      memcpy(md.PutDate,pMQMD->PutDate,8);
      memcpy(md.PutTime,pMQMD->PutTime,8);
    }
        
    MQPUT(hConn,hObj,&md,&pmo,messageLength,buffer, &cc, &rc);
    if (cc != MQCC_OK) 
    {
      if (prev_rc != rc) /* Log error, but only once in sequence */
      {	 	
	if (fp) fprintf(fp,"MQPUT failed. CC: %d RC: %d\n",cc,rc);
      }
      prev_rc = rc;
    }	
    memset(buffer,0,sizeof(buffer));
  }
  return;
}

/*********************************************************************/
/* This function returns TRUE if the requested operation is one of   */
/* the "DISPLAY" (Inquire) commands. Otherwise returns FALSE.        */
/*********************************************************************/
static int isInquire(MQLONG cmd)
{

  /*******************************************************************/
  /* This file is auto-generated by the makefile on AIX.             */
  /* Has lots of lines of the form                                   */
  /*    if (cmd == MQCMD_INQUIRE_XXXX) return TRUE;                  */
  /*******************************************************************/
#include "mqcmd.inc"

  return FALSE;
}
