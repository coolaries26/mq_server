Connect Wizard
--------------
The purpose of this wizard is to give a very simple way of connecting
two queue managers together. After completion of the wizard you should
have a matching set of channels running between the two queue managers, 
and some queues which can be used immediately to demonstrate successful 
message transfer.

Select two queue managers from the Explorer tree or table, right-click 
and select the "Create Queue Manager Links" option. 

The default values on the first page of the wizard are probably 
appropriate, but you can change all of the generated object names if you 
want. The "default defaults" can also be changed from the Preferences 
page or the Connect Wizard component of the MQ Explorer. 

On the final page of the wizard, the generated MQSC commands are shown 
in two panels  with one panel for each queue manager. These commands 
can be selected and copied into your own scripts for later review and 
modification.

Security Configuration
----------------------
One option on the first page is to select an SSL/TLS CipherSuite. The 
default is to leave this as "None" because you may not yet have set 
up the certificate configuration for each queue manager, and which is 
outside the scope of this wizard. However, if you know you already have 
that part of MQ defined, then select a CipherSuite.

One of the features of MQ V7.1 is to have additional security controls 
on who can connect to channels; configuration of those CHLAUTH resources 
is also outside the scope of this wizard.

Object Configuration
--------------------
The objects created consist of 
a) A sender channel, named "TO.<the other qmgr name>".
b) A receiver channel, named "TO.<this qmgr name>".   
c) A transmission queue named "<the other qmgr name>". This queue
   is defined with trigger controls so that the associated channel
   is automatically started when messages are put to the queue.
d) Optionally, a LOCALQ definition where you can receive messages,
   named "MS0P.CONNECT.GET.FROM.<the other qmgr name>".
e) Optionally,a REMOTEQ definition to send messages to the other 
   queue manager, pointing at the corresponding LOCALQ.

The "MS0P.CONNECT" qualifier can be changed in the Preferences panel for 
the wizard. If the queue managers names would make a generated name too 
long, then the right-most characters from the name are used to create a 
name up to the permitted maximum.  

-----------------------------------------------------
# SCCSID: @(#) com.ibm.mq.explorer.ms0p.connect/src/README.txt, supportpacs, MS0P  1.2 12/07/29 19:21:06